from flask import Flask, render_template, request, jsonify
from ai_send_quest import *
from flask_cors import CORS  # Импортируем CORS



# Настройка CORS

app = Flask(__name__)
CORS(app)

@app.route('/ai')
def index():
    return render_template('chat.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get("message")
    bot_reply = edit_gpt(user_message)
    return jsonify({"reply": bot_reply})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=9000, debug=True)

